# pdfme in Oracle Database 23ai MLE, called from Oracle APEX

Source files for the blog post "PDF Templating with Oracle MLE in Oracle APEX".

## Run order

| # | Where | What |
|---|---|---|
| 1 | DBA | `sql/01_grants.sql` (replace APP_SCHEMA with your parsing schema) |
| 2 | schema | `sql/02_hello_mle.sql` (optional smoke test) |
| 3 | schema | `sql/03_tables.sql` |
| 4 | PC | `npm install`, `npm run build`, `npm test` |
| 5 | schema | `sql/04_load_module_sqlcl.sql` in SQLcl (or `04b_load_module_bfile.sql`) |
| 6 | schema | `sql/05_call_specs.sql` |
| 7 | schema | `sql/06_pdfme_pkg.sql` |
| 8 | schema | `sql/07_skill_cert_template.sql` |
| 9 | schema | `sql/08_generate_test.sql` |
| 10 | schema | `sql/09_pdfme_designer.sql` |
| 11 | PC | `npm run build:designer`, then upload `dist/pdfme-designer.min.js` to `js/` and `dist/assets/*` to `js/assets/` in Static Application Files |
| 12 | APEX | build pages 3 and 4 as described in the post; page 4 JavaScript is `apex/page4_javascript.js` |

`sql/10_housekeeping.sql` holds the monitoring queries and the purge job. `apex/page_queries.sql` holds the list-of-values and report queries of pages 3 and 4.

## Layout

```
package.json  build.mjs  build-designer.mjs
src/        pdfme-mle.js  polyfills.js  stubs/date-fns-locale.js
            designer-entry.js  plugins.js  browser-shims.js
test/       mle-sim-test.mjs
templates/  skill_cert.template.json  skill_cert.inputs.json
sql/        01 ... 10 (see above)
apex/       page4_javascript.js  page_queries.sql
```

Built and tested with @pdfme 6.2.8 and esbuild 0.28. `npm test` runs the bundle in a Node vm context that imitates MLE;
`npm test -- skill_cert` renders the certificate template.
