function showError(msg) {
  apex.message.clearErrors();
  apex.message.showErrors([{ type: "error", location: "page", message: msg, unsafe: false }]);
}

function call(name, data) {
  return apex.server.process(name, data || {}, { dataType: "json" }).then(function (r) {
    if (!r || r.ok === false) { throw new Error((r && r.message) || "Request " + name + " failed"); }
    return r;
  }, function (jqXHR, status, err) {
    // a non-JSON reply (APEX prints "sqlerrm:ORA-..." for an unhandled callback error) is shown as is
    var text = jqXHR && jqXHR.responseText;
    throw new Error((jqXHR && jqXHR.responseJSON && jqXHR.responseJSON.message)
                    || (text ? name + ": " + text.replace(/^sqlerrm:/, "").substring(0, 400) : (err || status)));
  });
}

// pdfme Designer on APEX: load and save PDFME_TEMPLATE through the AJAX callbacks on this page.
// window.pdfmeApex comes from #APP_FILES#js/pdfme-designer.min.js (built from src/designer-entry.js, Step 10.6).
var PDFME = (function () {
  var NEW = "__NEW__";
  var designer = null, fonts = null, current = null, baseline = null, started = false;

  // pdfme sizes its canvas from its container, so the first template is loaded only when the container has a width,
  // so the first template is loaded only when the container first gets a width.
  function start() {
    var el = document.getElementById("pdfme-designer"), lastWidth = 0;
    new ResizeObserver(function () {
      var w = el.offsetWidth;
      if (w && !started) { started = true; load($v("P4_TEMPLATE_CODE")); }
      else if (w && !lastWidth) { window.dispatchEvent(new Event("resize")); }   // container shown again
      lastWidth = w;
    }).observe(el);
  }

  // Unsaved changes = the template differs from the last loaded/saved snapshot.
  // (onChangeTemplate also fires for programmatic updateTemplate, so it cannot track edits.)
  function snapshot() { return designer ? JSON.stringify(designer.getTemplate()) : null; }
  function markClean() { baseline = snapshot(); }
  function isDirty() { return !!designer && baseline !== null && snapshot() !== baseline; }

  function loadFonts() {
    if (fonts) { return Promise.resolve(fonts); }
    return call("GET_FONTS").then(function (r) { fonts = pdfmeApex.toPdfmeFonts(r.fonts); return fonts; });
  }

  function mount(tpl) {
    if (designer) { designer.updateTemplate(tpl); }
    else {
      var uiOptions = { font: fonts, lang: "en" };
      designer = new pdfmeApex.Designer({
        domContainer: document.getElementById("pdfme-designer"),
        template: tpl,
        plugins: pdfmeApex.plugins,
        options: uiOptions
      });
      designer.onSaveTemplate(function () { save("UPDATE"); });   // Ctrl+S in the Designer
    }
    markClean();
  }

  function load(code) {
    if (!started) { return; }      // still hidden: start() loads the current P4_TEMPLATE_CODE when shown
    if (isDirty() && !window.confirm("Discard unsaved changes to the current template?")) {
      apex.item("P4_TEMPLATE_CODE").setValue(current || NEW, null, true);
      return;
    }
    var spinner = apex.util.showSpinner($("#pdfme-designer"));
    Promise.resolve(loadFonts()).then(function () {
      if (!code || code === NEW) { current = null; mount(pdfmeApex.blankTemplate()); return null; }
      return call("GET_TEMPLATE", { x01: code }).then(function (r) { current = r.code; mount(r.template); });
    }).catch(function (e) { showError(e.message); })
      .then(function () { spinner.remove(); });
  }

  // mode UPDATE saves over the selected template, NEW inserts P4_NEW_CODE / P4_NEW_NAME
  function save(mode) {
    if (!designer) { return Promise.resolve(null); }
    var isNew = mode === "NEW" || !current;
    var code = isNew ? $v("P4_NEW_CODE") : current;
    var name = isNew ? $v("P4_NEW_NAME") : null;
    if (isNew && (!code || !name)) {
      showError("Enter a new template code and name, then click Save as new.");
      return Promise.resolve(null);
    }
    var tpl = designer.getTemplate();
    var envelope = JSON.stringify({ template: tpl, sampleInputs: pdfmeApex.getInputFromTemplate(tpl) });
    return call("SAVE_TEMPLATE", { x01: code, x02: name, x03: isNew ? "NEW" : "UPDATE", p_clob_01: envelope })
      .then(function (r) {
        markClean();
        if (isNew) {
          current = r.code;
          $("#P4_TEMPLATE_CODE").append(new Option(name + " (" + r.code + ")", r.code));
          apex.item("P4_TEMPLATE_CODE").setValue(r.code, null, true);
          apex.item("P4_NEW_CODE").setValue("");
          apex.item("P4_NEW_NAME").setValue("");
        }
        apex.message.showPageSuccess("Template " + r.code + " saved.");
        return r.code;
      })
      .catch(function (e) { showError(e.message); return null; });
  }

  // Save, then generate in the database (MLE) with the template's sample inputs, and open the PDF
  function test() {
    var win = window.open("about:blank", "pdfme_preview");   // opened now, so pop-up blockers allow it
    save("UPDATE").then(function (code) {
      if (!code) { if (win) { win.close(); } return null; }
      return call("TEST_PDF", { x01: code }).then(function (r) {
        if (win) { win.location.href = r.url; } else { apex.navigation.redirect(r.url); }
      });
    }).catch(function (e) { if (win) { win.close(); } showError(e.message); });
  }

  function chooseBackground() { document.getElementById("pdfme-bg-file").click(); }

  function setBackground(input) {
    var file = input.files && input.files[0];
    if (!file || !designer) { return; }
    var reader = new FileReader();
    reader.onload = function () {
      var tpl = designer.getTemplate();
      tpl.basePdf = reader.result;          // data:application/pdf;base64,... is stored in the template JSON
      designer.updateTemplate(tpl);
      input.value = "";
    };
    reader.readAsDataURL(file);
  }

  function blankBackground() {
    if (!designer) { return; }
    var tpl = designer.getTemplate();
    tpl.basePdf = { width: 210, height: 297, padding: [0, 0, 0, 0] };
    designer.updateTemplate(tpl);
  }

  window.addEventListener("beforeunload", function (e) { if (isDirty()) { e.preventDefault(); e.returnValue = ""; } });

  return { start: start, load: load, save: save, test: test, chooseBackground: chooseBackground,
           setBackground: setBackground, blankBackground: blankBackground };
})();
