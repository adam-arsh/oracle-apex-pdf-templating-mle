-- Queries used by the APEX pages (Step 10).

-- Page 3, item P3_TEMPLATE_CODE: list of values
SELECT template_name AS d,
       template_code AS r
  FROM pdfme_template
 WHERE is_active = 'Y'
 ORDER BY template_name

-- Page 3, region "My recent PDFs" (Static ID pdf_history)
SELECT j.job_id,
       t.template_name,
       j.file_name,
       j.status,
       CASE WHEN j.pdf_size IS NOT NULL
            THEN ROUND(j.pdf_size / 1024, 1) || ' KB' END AS pdf_size,
       j.elapsed_ms,
       TO_CHAR(j.created_on, 'DD-Mon-YYYY HH24:MI:SS')     AS created_on,
       SUBSTR(j.error_message, 1, 300)                     AS error_message,
       CASE WHEN j.status = 'DONE' THEN 'Download' END     AS download
  FROM pdfme_job      j
  JOIN pdfme_template t ON t.template_id = j.template_id
 WHERE j.created_by = :APP_USER
 ORDER BY j.job_id DESC
 FETCH FIRST 15 ROWS ONLY

-- Page 4, item P4_TEMPLATE_CODE: list of values
SELECT d, r
  FROM (SELECT template_name || ' - ' || template_code
               || CASE is_active WHEN 'N' THEN ' - inactive' END AS d,
               template_code AS r,
               1 AS grp
          FROM pdfme_template
         UNION ALL
        SELECT '+ New blank template', '__NEW__', 2 FROM dual)
 ORDER BY grp, d
