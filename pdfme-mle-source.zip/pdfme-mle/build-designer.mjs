// Builds dist/pdfme-designer.min.js: the pdfme Designer (React UI) as one browser script.
// It defines window.pdfmeApex. Load it on APEX page 4 as #APP_FILES#js/pdfme-designer.min.js.
//   npm run build:designer
import * as esbuild from 'esbuild';
import { statSync, readdirSync, mkdirSync } from 'node:fs';

const outfile = 'dist/pdfme-designer.min.js';

await esbuild.build({
  entryPoints: ['src/designer-entry.js'],
  outfile,
  bundle: true,
  format: 'iife',
  platform: 'browser',
  target: ['es2020', 'chrome100', 'firefox100', 'safari15', 'edge100'],
  // @pdfme/converter finds its worker with new URL('assets/clawpdf-worker-*.js', import.meta.url).
  // A classic script has no import.meta, so use this script's own URL instead (#APP_FILES#js/...).
  banner: { js: 'var __pdfmeApexBase=(document.currentScript&&document.currentScript.src)||location.href;' },
  define: { 'process.env.NODE_ENV': '"production"', global: 'globalThis', 'import.meta.url': '__pdfmeApexBase' },
  inject: ['src/browser-shims.js'],
  external: ['node:*'], // clawpdf imports these dynamically, only on Node; never called in a browser
  minify: true,
  legalComments: 'eof',
  charset: 'utf8',
  loader: { '.ttf': 'binary', '.woff': 'binary', '.woff2': 'binary' },
  logLevel: 'info',
});

// The pdfium worker (only used for templates with a custom PDF background): minify it and
// write it to dist/assets/, which maps to #APP_FILES#js/assets/ in APEX
const workerDir = 'node_modules/@pdfme/converter/dist/assets/';
const worker = readdirSync(workerDir).find((f) => /^clawpdf-worker-.*\.js$/.test(f));
mkdirSync('dist/assets', { recursive: true });
await esbuild.build({
  entryPoints: [workerDir + worker], outfile: 'dist/assets/' + worker,
  bundle: false, minify: true, format: 'iife', legalComments: 'eof', logLevel: 'warning',
  define: { 'process.env.NODE_ENV': '"production"' },
});
console.log(`worker: dist/assets/${worker} (${(statSync('dist/assets/' + worker).size / 1024).toFixed(0)} KB)`);

console.log(`designer bundle: ${outfile} (${(statSync(outfile).size / 1024).toFixed(0)} KB)`);
