// Builds dist/pdfme_mle_bundle.js: one ES module that you load as MLE module PDFME_BUNDLE.
//   npm install
//   npm run build
import * as esbuild from 'esbuild';
import { statSync, readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

const outfile = 'dist/pdfme_mle_bundle.js';

// Replaces 'date-fns/locale' (every locale) with an en-US-only stub
const stubDateFnsLocales = {
  name: 'stub-date-fns-locales',
  setup(build) {
    build.onResolve({ filter: /^date-fns\/locale$/ }, () => ({
      path: fileURLToPath(new URL('./src/stubs/date-fns-locale.js', import.meta.url)),
    }));
  },
};

await esbuild.build({
  entryPoints: ['src/pdfme-mle.js'],
  outfile,
  bundle: true,
  format: 'esm',             // MLE modules are ECMAScript modules
  platform: 'browser',       // uses the browser builds of fontkit / pdf-lib, so no node:* imports
  target: 'es2022',          // GraalJS in 23ai handles ES2022
  mainFields: ['module', 'main'],
  conditions: ['import', 'default'],
  inject: ['src/polyfills.js'],
  external: ['mle-js-oracledb', 'mle-js-plsqltypes', 'mle-js-bindings'], // built into the database
  define: {
    'process.env.NODE_ENV': '"production"',
    global: 'globalThis',
  },
  minify: true,
  legalComments: 'eof',
  charset: 'ascii', // non-ASCII is written as \u escapes, so the load works whatever the client NLS_LANG is
  plugins: [stubDateFnsLocales],
  logLevel: 'info',
});

// esbuild leaves raw characters inside regex literals (for example the Japan Post barcode
// pattern). Escape them too, so the module file is pure 7-bit ASCII.
const src = readFileSync(outfile, 'utf8');
const ascii = src.replace(/[^\u0000-\u007f]/g, (c) => '\\u' + c.charCodeAt(0).toString(16).padStart(4, '0'));
writeFileSync(outfile, ascii, 'ascii');

console.log(`bundle: ${outfile} (${(statSync(outfile).size / 1024).toFixed(0)} KB)`);
