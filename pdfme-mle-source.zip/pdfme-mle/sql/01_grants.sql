-- Run as a DBA (ADMIN on Autonomous Database, SYSTEM elsewhere).
-- Replace APP_SCHEMA with your APEX parsing schema.
GRANT CREATE MLE            TO app_schema;   -- CREATE MLE MODULE / ENV
GRANT EXECUTE ON JAVASCRIPT TO app_schema;   -- run JavaScript in the database
GRANT CREATE PROCEDURE      TO app_schema;   -- call specs and the API package
GRANT CREATE TABLE          TO app_schema;

-- Shortcut on 23ai: DB_DEVELOPER_ROLE already contains CREATE MLE and EXECUTE ON JAVASCRIPT
-- GRANT DB_DEVELOPER_ROLE TO app_schema;
