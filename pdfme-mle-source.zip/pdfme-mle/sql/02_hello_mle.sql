-- Run as APP_SCHEMA. A JavaScript module, a call spec that exposes it to SQL, then a query.
CREATE OR REPLACE MLE MODULE hello_mod LANGUAGE JAVASCRIPT AS
export function greet(name) {
  return `Hello, ${name}! This ran as JavaScript inside the database.`;
}
/

CREATE OR REPLACE FUNCTION hello_greet (p_name IN VARCHAR2) RETURN VARCHAR2
AS MLE MODULE hello_mod
SIGNATURE 'greet(string)';
/

SELECT hello_greet('APEX') AS greeting FROM dual;

-- Clean up once it works
DROP FUNCTION hello_greet;
DROP MLE MODULE hello_mod;
