-- Run as APP_SCHEMA, inside SQLcl, from your project folder (the one that contains dist/).
--   sql app_schema@your_db
mle create-module -replace -filename dist/pdfme_mle_bundle.js -module-name PDFME_BUNDLE -version 1.0.0

SELECT module_name, version, language_name, created
  FROM user_mle_modules
 WHERE module_name = 'PDFME_BUNDLE';
