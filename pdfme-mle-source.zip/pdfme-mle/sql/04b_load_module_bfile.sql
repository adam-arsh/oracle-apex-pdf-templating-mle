-- Option B. The database reads the bundle from a directory on the DB server.
-- DBA, once:
CREATE OR REPLACE DIRECTORY pdfme_dir AS '/u01/app/pdfme';
GRANT READ ON DIRECTORY pdfme_dir TO app_schema;
-- Copy dist/pdfme_mle_bundle.js into that server folder, then, as APP_SCHEMA:
CREATE OR REPLACE MLE MODULE pdfme_bundle
    LANGUAGE JAVASCRIPT
    VERSION '1.0.0'
    USING BFILE (pdfme_dir, 'pdfme_mle_bundle.js')
/
