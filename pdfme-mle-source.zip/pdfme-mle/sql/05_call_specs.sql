-- Run as APP_SCHEMA, after the module exists.
-- JavaScript export                 PL/SQL
-- bundleInfo()           string     function  bundle_info  RETURN VARCHAR2
-- runJob(jobId)          void       procedure run_job(p_job_id)
-- resultSize()           number     function  result_size  RETURN NUMBER
-- resultChunk(off, amt)  Uint8Array function  result_chunk RETURN RAW    (Uint8Array <-> RAW)
-- clearResult()          void       procedure clear_result
CREATE OR REPLACE PACKAGE pdfme_mle AS

    FUNCTION bundle_info RETURN VARCHAR2
        AS MLE MODULE pdfme_bundle
        SIGNATURE 'bundleInfo()';

    PROCEDURE run_job (p_job_id IN NUMBER)
        AS MLE MODULE pdfme_bundle
        SIGNATURE 'runJob(number)';

    FUNCTION result_size RETURN NUMBER
        AS MLE MODULE pdfme_bundle
        SIGNATURE 'resultSize()';

    FUNCTION result_chunk (p_offset IN NUMBER, p_amount IN NUMBER) RETURN RAW
        AS MLE MODULE pdfme_bundle
        SIGNATURE 'resultChunk(number, number)';

    PROCEDURE clear_result
        AS MLE MODULE pdfme_bundle
        SIGNATURE 'clearResult()';

END pdfme_mle;
/

-- Smoke test: loads the module into an MLE context and returns its version string
SELECT pdfme_mle.bundle_info() AS bundle FROM dual;
