-- Run as APP_SCHEMA, after the call specifications (Step 6).
-- PDFME_PKG: the PL/SQL API that APEX (or any code) calls.
--
--   l_job := pdfme_pkg.generate_job('SKILL_CERT', l_inputs_json);   -- runs pdfme in MLE, stores the PDF
--   l_pdf := pdfme_pkg.get_pdf(l_job);                              -- the BLOB (mail it, archive it, ...)
--   pdfme_pkg.download_job(l_job, p_inline => 'N');                 -- stream to the browser (GET request only)
--
-- Call generate_* from PL/SQL (an APEX process, a DA, a job), not from a SELECT: it writes
-- PDFME_JOB and commits a failed job row so that the error is kept.

create or replace package pdfme_pkg as

    c_chunk constant pls_integer := 32000;   -- RAW slice size pulled from MLE (max 32767)

    -- Runs pdfme generate() for a template and JSON inputs. Returns PDFME_JOB.JOB_ID (status DONE, PDF in pdf_blob).
    -- p_inputs: a JSON array of input objects (one set of pages per object) or a single object.
    function generate_job (
        p_template_code in varchar2,
        p_inputs        in clob,
        p_file_name     in varchar2 default null
    ) return number;

    -- Same, but returns the PDF itself
    function generate_pdf (
        p_template_code in varchar2,
        p_inputs        in clob
    ) return blob;

    function get_pdf (p_job_id in number) return blob;

    -- Streams a generated PDF and stops the APEX engine. Call only on a GET page request
    -- (a Before Header process), never from an AJAX/After Submit process.
    procedure download_job (
        p_job_id in number,
        p_inline in varchar2 default 'N'      -- Y = open in the browser tab, N = save as attachment
    );

    -- Generate and stream in one call (GET request only)
    procedure download (
        p_template_code in varchar2,
        p_inputs        in clob,
        p_file_name     in varchar2 default null,
        p_inline        in varchar2 default 'N'
    );

    function sample_inputs (p_template_code in varchar2) return clob;
    function template_json_pretty (p_template_code in varchar2) return clob;

    -- Raises ORA-20001 with a readable message when p_inputs is not usable JSON
    procedure validate_inputs (p_inputs in clob);


end pdfme_pkg;
/

create or replace package body pdfme_pkg as

    function current_user_name return varchar2 is
    begin
        return coalesce(sys_context('APEX$SESSION', 'APP_USER'), sys_context('USERENV', 'SESSION_USER'));
    end current_user_name;

    function ms_since (p_start in timestamp with time zone) return number is
        l_d interval day(3) to second(3) := systimestamp - p_start;
    begin
        return round(((extract(day from l_d) * 24 + extract(hour from l_d)) * 60 + extract(minute from l_d)) * 60000
                     + extract(second from l_d) * 1000);
    end ms_since;

    function safe_file_name (p_name in varchar2, p_default in varchar2) return varchar2 is
        l_name varchar2(255 char);
    begin
        l_name := regexp_replace(trim(coalesce(p_name, p_default, 'document.pdf')), '[^A-Za-z0-9._-]+', '_');
        if lower(l_name) not like '%.pdf' then
            l_name := substr(l_name, 1, 250) || '.pdf';
        end if;
        return l_name;
    end safe_file_name;

    procedure validate_inputs (p_inputs in clob) is
        l_ok   pls_integer;
        l_type varchar2(30);
    begin
        if p_inputs is null or dbms_lob.getlength(p_inputs) = 0 then
            raise_application_error(-20001, 'Inputs are empty. Enter a JSON array such as [{"field":"value"}].');
        end if;
        select count(*) into l_ok from dual where p_inputs is json;
        if l_ok = 0 then
            raise_application_error(-20001, 'Inputs are not valid JSON.');
        end if;
        select json_value(p_inputs, '$.type()') into l_type from dual;
        if l_type not in ('array', 'object') then
            raise_application_error(-20001, 'Inputs must be a JSON array of objects (or a single object).');
        end if;
    end validate_inputs;

    -- Reads the PDF that runJob left in the MLE context, as RAW slices, into a BLOB
    function pull_result return blob is
        l_size number;
        l_off  number := 1;
        l_raw  raw(32767);
        l_pdf  blob;
    begin
        l_size := pdfme_mle.result_size;   -- raises the JavaScript error text if generate() failed
        dbms_lob.createtemporary(l_pdf, true, dbms_lob.call);
        while l_off <= l_size loop
            l_raw := pdfme_mle.result_chunk(l_off, c_chunk);
            dbms_lob.writeappend(l_pdf, utl_raw.length(l_raw), l_raw);
            l_off := l_off + c_chunk;
        end loop;
        pdfme_mle.clear_result;
        return l_pdf;
    end pull_result;

    function generate_job (
        p_template_code in varchar2,
        p_inputs        in clob,
        p_file_name     in varchar2 default null
    ) return number is
        l_start       timestamp with time zone := systimestamp;
        l_template_id pdfme_template.template_id%type;
        l_default     pdfme_template.default_file_name%type;
        l_job_id      pdfme_job.job_id%type;
        l_pdf         blob;
        l_err         varchar2(4000 char);
        l_file_name   pdfme_job.file_name%type;
        l_ms          number;
    begin
        begin
            select template_id, default_file_name
              into l_template_id, l_default
              from pdfme_template
             where template_code = p_template_code
               and is_active = 'Y';
        exception
            when no_data_found then
                raise_application_error(-20002, 'Template "' || p_template_code || '" does not exist or is inactive.');
        end;

        validate_inputs(p_inputs);

        -- private functions cannot be called inside SQL (PLS-00231), so compute into variables first
        l_file_name := safe_file_name(p_file_name, l_default);

        insert into pdfme_job (template_id, inputs_json, status, file_name)
        values (l_template_id, p_inputs, 'RUNNING', l_file_name)
        returning job_id into l_job_id;

        begin
            pdfme_mle.run_job(l_job_id);   -- JavaScript reads this uncommitted row (same session)
            l_pdf := pull_result;
            l_ms  := ms_since(l_start);

            update pdfme_job
               set status     = 'DONE',
                   pdf_blob   = l_pdf,
                   pdf_size   = dbms_lob.getlength(l_pdf),
                   elapsed_ms = l_ms
             where job_id = l_job_id;
        exception
            when others then
                l_err := substr(sqlerrm || chr(10) || dbms_utility.format_error_backtrace, 1, 4000);
                l_ms  := ms_since(l_start);
                update pdfme_job
                   set status = 'ERROR', error_message = l_err, elapsed_ms = l_ms
                 where job_id = l_job_id;
                commit;   -- keep the failed job row for diagnosis
                raise_application_error(-20100, 'PDF generation failed (job ' || l_job_id || '): '
                                                || substr(sqlerrm, 1, 1500));
        end;

        return l_job_id;
    end generate_job;

    function generate_pdf (
        p_template_code in varchar2,
        p_inputs        in clob
    ) return blob is
    begin
        return get_pdf(generate_job(p_template_code, p_inputs));
    end generate_pdf;

    function get_pdf (p_job_id in number) return blob is
        l_pdf blob;
    begin
        select pdf_blob into l_pdf from pdfme_job where job_id = p_job_id and status = 'DONE';
        return l_pdf;
    exception
        when no_data_found then
            raise_application_error(-20003, 'PDF job ' || p_job_id || ' not found or not finished.');
    end get_pdf;

    procedure download_job (
        p_job_id in number,
        p_inline in varchar2 default 'N'
    ) is
        l_pdf  blob;
        l_name pdfme_job.file_name%type;
        l_user pdfme_job.created_by%type := current_user_name;
    begin
        begin
            select pdf_blob, file_name
              into l_pdf, l_name
              from pdfme_job
             where job_id     = p_job_id
               and status     = 'DONE'
               and created_by = l_user;   -- users stream only their own PDFs
        exception
            when no_data_found then
                raise_application_error(-20003, 'PDF job ' || p_job_id || ' not found.');
        end;

        sys.htp.init;
        sys.owa_util.mime_header('application/pdf', false);
        sys.htp.p('Content-Length: ' || dbms_lob.getlength(l_pdf));
        sys.htp.p('Content-Disposition: ' || case p_inline when 'Y' then 'inline' else 'attachment' end
                  || '; filename="' || l_name || '"');
        sys.htp.p('Cache-Control: private, no-store');
        sys.owa_util.http_header_close;
        sys.wpg_docload.download_file(l_pdf);
        apex_application.stop_apex_engine;   -- raises e_stop_apex_engine: do not wrap in WHEN OTHERS
    end download_job;

    procedure download (
        p_template_code in varchar2,
        p_inputs        in clob,
        p_file_name     in varchar2 default null,
        p_inline        in varchar2 default 'N'
    ) is
        l_job_id number;
    begin
        l_job_id := generate_job(p_template_code, p_inputs, p_file_name);
        commit;
        download_job(l_job_id, p_inline);
    end download;

    function sample_inputs (p_template_code in varchar2) return clob is
        l_inputs clob;
    begin
        select coalesce(sample_inputs, to_clob('[{}]'))
          into l_inputs
          from pdfme_template
         where template_code = p_template_code;
        return l_inputs;
    exception
        when no_data_found then
            return null;
    end sample_inputs;

    function template_json_pretty (p_template_code in varchar2) return clob is
        l_json clob;
    begin
        select json_serialize(template_json returning clob pretty)
          into l_json
          from pdfme_template
         where template_code = p_template_code;
        return l_json;
    exception
        when no_data_found then
            return null;
    end template_json_pretty;

end pdfme_pkg;
/

show errors package body pdfme_pkg
