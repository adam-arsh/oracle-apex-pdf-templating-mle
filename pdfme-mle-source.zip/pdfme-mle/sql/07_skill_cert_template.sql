-- Run as APP_SCHEMA. Stores the SKILL_CERT template and its sample inputs.
-- Safe to re-run: the MERGE updates the row when it exists.
SET DEFINE OFF
DECLARE
    l_tpl CLOB := q'~{
  "title": "TalentHub - Certificate of Skill Validation",
  "basePdf": {"width": 297, "height": 210, "padding": [0, 0, 0, 0]},
  "schemas": [[
    {"name": "frame_outer", "type": "rectangle", "readOnly": true, "position": {"x": 8, "y": 8},
     "width": 281, "height": 194, "borderWidth": 1.2, "borderColor": "#1f4e79", "color": "",
     "radius": 0},
    {"name": "frame_inner", "type": "rectangle", "readOnly": true, "position": {"x": 12, "y": 12},
     "width": 273, "height": 186, "borderWidth": 0.4, "borderColor": "#9dc3e6", "color": "",
     "radius": 0},
    {"name": "brand", "type": "text", "readOnly": true, "content": "KOVAION  TALENTHUB",
     "position": {"x": 20, "y": 24}, "width": 257, "height": 8, "fontSize": 11,
     "characterSpacing": 3, "alignment": "center", "fontColor": "#2e75b6", "fontName": "Roboto"},
    {"name": "heading", "type": "text", "readOnly": true,
     "content": "Certificate of Skill Validation", "position": {"x": 20, "y": 38}, "width": 257,
     "height": 16, "fontSize": 30, "alignment": "center", "fontColor": "#1f2937",
     "fontName": "Roboto"},
    {"name": "certify", "type": "text", "readOnly": true, "content": "This is to certify that",
     "position": {"x": 20, "y": 66}, "width": 257, "height": 8, "fontSize": 13,
     "alignment": "center", "fontColor": "#4b5563", "fontName": "Roboto"},
    {"name": "employee_name", "type": "text", "content": "Employee Name",
     "position": {"x": 20, "y": 78}, "width": 257, "height": 16, "fontSize": 28,
     "alignment": "center", "fontColor": "#1f4e79", "fontName": "Roboto",
     "dynamicFontSize": {"min": 16, "max": 28, "fit": "horizontal"}},
    {"name": "name_rule", "type": "line", "readOnly": true, "position": {"x": 88.5, "y": 97},
     "width": 120, "height": 0.4, "color": "#9dc3e6"},
    {"name": "statement", "type": "text", "content": "has demonstrated proficiency in",
     "position": {"x": 30, "y": 104}, "width": 237, "height": 8, "fontSize": 13,
     "alignment": "center", "fontColor": "#4b5563", "fontName": "Roboto"},
    {"name": "skill_name", "type": "text", "content": "Skill", "position": {"x": 20, "y": 115},
     "width": 257, "height": 12, "fontSize": 22, "alignment": "center", "fontColor": "#111827",
     "fontName": "Roboto"},
    {"name": "proficiency", "type": "text", "content": "Level", "position": {"x": 20, "y": 130},
     "width": 257, "height": 8, "fontSize": 13, "alignment": "center", "fontColor": "#2e75b6",
     "fontName": "Roboto"},
    {"name": "issued_on", "type": "text", "content": "01-Jan-2026", "position": {"x": 30, "y": 166},
     "width": 70, "height": 7, "fontSize": 12, "alignment": "center", "fontColor": "#111827",
     "fontName": "Roboto"},
    {"name": "issued_rule", "type": "line", "readOnly": true, "position": {"x": 35, "y": 174},
     "width": 60, "height": 0.3, "color": "#6b7280"},
    {"name": "issued_label", "type": "text", "readOnly": true, "content": "Date of issue",
     "position": {"x": 30, "y": 176}, "width": 70, "height": 6, "fontSize": 9,
     "alignment": "center", "fontColor": "#6b7280", "fontName": "Roboto"},
    {"name": "validator", "type": "text", "content": "Validator",
     "position": {"x": 113.5, "y": 166}, "width": 70, "height": 7, "fontSize": 12,
     "alignment": "center", "fontColor": "#111827", "fontName": "Roboto"},
    {"name": "validator_rule", "type": "line", "readOnly": true, "position": {"x": 118.5, "y": 174},
     "width": 60, "height": 0.3, "color": "#6b7280"},
    {"name": "validator_label", "type": "text", "readOnly": true, "content": "Validated by",
     "position": {"x": 113.5, "y": 176}, "width": 70, "height": 6, "fontSize": 9,
     "alignment": "center", "fontColor": "#6b7280", "fontName": "Roboto"},
    {"name": "verify_qr", "type": "qrcode", "content": "https://example.com",
     "position": {"x": 236, "y": 150}, "width": 30, "height": 30, "barColor": "#1f2937",
     "backgroundColor": "#ffffff"},
    {"name": "cert_no", "type": "text", "content": "TH-CERT-0000", "position": {"x": 216, "y": 182},
     "width": 70, "height": 6, "fontSize": 8, "alignment": "center", "fontColor": "#6b7280",
     "fontName": "Roboto"}
  ]]
}~';
    l_inp CLOB := q'~[
  {
    "employee_name": "Priya Raman",
    "statement": "has demonstrated proficiency in",
    "skill_name": "Oracle APEX Development",
    "proficiency": "Level 4 - Advanced",
    "issued_on": "21-Oct-2026",
    "validator": "Karthik Subramanian",
    "verify_qr": "https://talenthub.kovaion.com/verify/TH-CERT-2026-00042",
    "cert_no": "TH-CERT-2026-00042"
  }
]~';
BEGIN
    MERGE INTO pdfme_template t
    USING (SELECT 'SKILL_CERT' AS template_code FROM dual) s
       ON (t.template_code = s.template_code)
     WHEN MATCHED THEN UPDATE SET
          t.template_name     = 'Certificate of Skill Validation',
          t.description       = 'A4 landscape certificate with a QR verification code',
          t.default_file_name = 'skill_certificate.pdf',
          t.template_json     = l_tpl,
          t.sample_inputs     = l_inp,
          t.is_active         = 'Y'
     WHEN NOT MATCHED THEN INSERT
          (template_code, template_name, description, default_file_name, template_json, sample_inputs)
          VALUES ('SKILL_CERT', 'Certificate of Skill Validation',
                  'A4 landscape certificate with a QR verification code',
                  'skill_certificate.pdf', l_tpl, l_inp);
    COMMIT;
END;
/
