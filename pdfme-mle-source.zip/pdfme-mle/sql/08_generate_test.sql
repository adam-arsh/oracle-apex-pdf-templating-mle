-- Run as APP_SCHEMA. Generates the certificate from SQL (no APEX) and checks that the result is a PDF.
SET SERVEROUTPUT ON SIZE UNLIMITED

SELECT pdfme_mle.bundle_info() AS bundle FROM dual;

DECLARE
    l_inputs CLOB;
    l_job    NUMBER;
    l_pdf    BLOB;
    l_ms     NUMBER;
    l_head   VARCHAR2(5);
BEGIN
    SELECT sample_inputs INTO l_inputs FROM pdfme_template WHERE template_code = 'SKILL_CERT';

    FOR i IN 1 .. 2 LOOP   -- 1 = cold (module and fonts load), 2 = warm (cached in this session)
        l_job := pdfme_pkg.generate_job('SKILL_CERT', l_inputs);
        SELECT pdf_blob, elapsed_ms INTO l_pdf, l_ms FROM pdfme_job WHERE job_id = l_job;
        l_head := UTL_RAW.CAST_TO_VARCHAR2(DBMS_LOB.SUBSTR(l_pdf, 5, 1));
        DBMS_OUTPUT.PUT_LINE(CASE i WHEN 1 THEN 'cold' ELSE 'warm' END
                             || ' job ' || l_job || ': ' || DBMS_LOB.GETLENGTH(l_pdf) || ' bytes, '
                             || l_ms || ' ms, header ' || l_head);
        IF l_head <> '%PDF-' THEN
            RAISE_APPLICATION_ERROR(-20000, 'The result is not a PDF');
        END IF;
    END LOOP;
    COMMIT;
END;
/

-- Negative test: bad JSON must give a readable ORA-20001
BEGIN
    DBMS_OUTPUT.PUT_LINE(pdfme_pkg.generate_job('SKILL_CERT', '{not json'));
EXCEPTION
    WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('expected error: ' || SQLERRM);
END;
/
