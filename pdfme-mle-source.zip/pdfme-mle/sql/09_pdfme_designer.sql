-- Run as APP_SCHEMA, after PDFME_PKG (Step 7).
-- PDFME_DESIGNER: AJAX endpoints for the pdfme Designer on APEX page 4.
--
--   GET_TEMPLATE   x01 = template code
--   GET_FONTS      no parameters
--   SAVE_TEMPLATE  x01 = code, x02 = name, x03 = UPDATE or NEW, clob_01 = envelope
--   TEST_PDF       x01 = template code
--
-- Every endpoint prints JSON. Errors come back as {"ok":false,"message":"..."}
-- so the page can show them as a normal message.

create or replace package pdfme_designer as

    procedure ajax_get_template (p_code in varchar2);

    procedure ajax_get_fonts;

    procedure ajax_save_template (
        p_code     in varchar2,
        p_name     in varchar2,
        p_mode     in varchar2,     -- UPDATE (existing code) or NEW (insert; code must not exist)
        p_envelope in clob
    );

    procedure ajax_test_pdf (p_code in varchar2);

end pdfme_designer;
/

create or replace package body pdfme_designer as

    c_chunk constant pls_integer := 8000;

    procedure print_clob (p_clob in clob) is
        l_len number := nvl(dbms_lob.getlength(p_clob), 0);
        l_off number := 1;
    begin
        while l_off <= l_len loop
            sys.htp.prn(dbms_lob.substr(p_clob, c_chunk, l_off));
            l_off := l_off + c_chunk;
        end loop;
    end print_clob;

    procedure print_error (p_message in varchar2) is
    begin
        sys.htp.prn('{"ok":false,"message":' || apex_json.stringify(p_message) || '}');
    end print_error;

    -- ORA-20xxx: message text only, without the "ORA-20001: " prefix
    function clean_sqlerrm return varchar2 is
    begin
        return regexp_replace(sqlerrm, '^ORA-\d+: ');
    end clean_sqlerrm;

    procedure ajax_get_template (p_code in varchar2) is
        l_name pdfme_template.template_name%type;
        l_json clob;
    begin
        select template_name, template_json
          into l_name, l_json
          from pdfme_template
         where template_code = p_code;

        sys.htp.prn('{"ok":true,"code":' || apex_json.stringify(p_code)
                    || ',"name":' || apex_json.stringify(l_name) || ',"template":');
        print_clob(l_json);
        sys.htp.prn('}');
    exception
        when no_data_found then
            print_error('Template ' || p_code || ' not found.');
    end ajax_get_template;

    procedure ajax_get_fonts is
        l_first boolean := true;
        l_b64   clob;
    begin
        sys.htp.prn('{"ok":true,"fonts":{');
        for f in (select font_name, font_data, is_fallback, is_subset
                    from pdfme_font
                   where is_active = 'Y'
                   order by case is_fallback when 'Y' then 0 else 1 end, font_name)
        loop
            -- blob2clobbase64 wraps lines, and a JSON string must not contain raw CR/LF
            l_b64 := replace(replace(apex_web_service.blob2clobbase64(f.font_data), chr(13)), chr(10));
            sys.htp.prn(case when not l_first then ',' end
                        || apex_json.stringify(f.font_name) || ':{"fallback":'
                        || case f.is_fallback when 'Y' then 'true' else 'false' end
                        || ',"subset":' || case f.is_subset when 'N' then 'false' else 'true' end
                        || ',"b64":"');
            print_clob(l_b64);
            sys.htp.prn('"}');
            l_first := false;
        end loop;
        sys.htp.prn('}}');
    end ajax_get_fonts;

    procedure ajax_save_template (
        p_code     in varchar2,
        p_name     in varchar2,
        p_mode     in varchar2,
        p_envelope in clob
    ) is
        l_code     pdfme_template.template_code%type := upper(trim(p_code));
        l_ok       pls_integer;
        l_template clob;
        l_inputs   clob;
        l_old      clob;
    begin
        if l_code is null or not regexp_like(l_code, '^[A-Z][A-Z0-9_]{1,49}$') then
            raise_application_error(-20010, 'Template code must start with a letter and use only A-Z, 0-9 and _ (2-50 characters).');
        end if;

        select count(*) into l_ok from dual where p_envelope is json;
        if l_ok = 0 then
            raise_application_error(-20011, 'The Designer sent invalid JSON.');
        end if;

        select json_query(p_envelope, '$.template' returning clob),
               json_query(p_envelope, '$.sampleInputs' returning clob)
          into l_template, l_inputs
          from dual;
        if l_template is null then
            raise_application_error(-20012, 'The Designer sent no template.');
        end if;

        if p_mode = 'NEW' then
            if trim(p_name) is null then
                raise_application_error(-20013, 'Enter a name for the new template.');
            end if;
            insert into pdfme_template (template_code, template_name, template_json, sample_inputs, default_file_name)
            values (l_code, trim(p_name), l_template, l_inputs, lower(l_code) || '.pdf');
        else
            select sample_inputs into l_old from pdfme_template where template_code = l_code for update;

            -- Keep the curated sample values: new fields get the Designer defaults, existing ones keep their value
            if l_old is not null and l_inputs is not null then
                select '[' || json_mergepatch(json_query(l_inputs, '$[0]' returning clob),
                                              json_query(l_old, '$[0]' returning clob)
                                              returning clob) || ']'
                  into l_inputs
                  from dual;
            end if;

            update pdfme_template
               set template_json = l_template,
                   sample_inputs = coalesce(l_inputs, sample_inputs),
                   template_name = coalesce(trim(p_name), template_name)
             where template_code = l_code;
        end if;

        commit;
        sys.htp.prn('{"ok":true,"code":' || apex_json.stringify(l_code) || '}');
    exception
        when dup_val_on_index then
            rollback;
            print_error('Template code ' || l_code || ' already exists. Choose another code.');
        when no_data_found then
            rollback;
            print_error('Template ' || l_code || ' not found. Use "Save as new".');
        when others then
            rollback;
            print_error(clean_sqlerrm);
    end ajax_save_template;

    procedure ajax_test_pdf (p_code in varchar2) is
        l_job_id number;
    begin
        -- the real path: MLE generate() with the template's saved sample inputs
        l_job_id := pdfme_pkg.generate_job(p_code, pdfme_pkg.sample_inputs(p_code));
        commit;
        sys.htp.prn('{"ok":true,"jobId":' || l_job_id || ',"url":'
                    || apex_json.stringify(apex_page.get_url(
                           p_page    => 3,
                           p_request => 'JOBVIEW',
                           p_items   => 'P3_JOB_ID',
                           p_values  => l_job_id)) || '}');
    exception
        when others then
            print_error(clean_sqlerrm);
    end ajax_test_pdf;

end pdfme_designer;
/
