-- Latest jobs, with any error
SELECT job_id, status, pdf_size, elapsed_ms, created_by, created_on,
       SUBSTR(error_message, 1, 200) AS error
  FROM pdfme_job
 ORDER BY job_id DESC
 FETCH FIRST 20 ROWS ONLY;

-- Health per template
SELECT t.template_code,
       COUNT(*)                                        AS jobs,
       ROUND(AVG(j.elapsed_ms))                        AS avg_ms,
       MAX(j.elapsed_ms)                               AS max_ms,
       SUM(CASE WHEN j.status = 'ERROR' THEN 1 END)    AS errors
  FROM pdfme_job j
  JOIN pdfme_template t ON t.template_id = j.template_id
 GROUP BY t.template_code;

-- Keep 30 days of generated PDFs: a nightly purge at 02:00
BEGIN
    DBMS_SCHEDULER.CREATE_JOB(
        job_name        => 'PDFME_PURGE_JOBS',
        job_type        => 'PLSQL_BLOCK',
        job_action      => 'BEGIN DELETE FROM pdfme_job WHERE created_on < SYSTIMESTAMP - INTERVAL ''30'' DAY; COMMIT; END;',
        repeat_interval => 'FREQ=DAILY;BYHOUR=2;BYMINUTE=0',
        enabled         => TRUE);
END;
/
