// Browsers have no Buffer, but @pdfme/common uses it for base64 helpers
import { Buffer } from 'buffer';

if (typeof globalThis.Buffer === 'undefined') globalThis.Buffer = Buffer;
