// Browser bundle for the pdfme Designer on APEX page 4 -> dist/pdfme-designer.min.js
// It exposes window.pdfmeApex. The APEX page JavaScript does the rest (load, save, fonts).
import { Designer } from '@pdfme/ui';
import { BLANK_PDF, getInputFromTemplate, getDefaultFont } from '@pdfme/common';
import { plugins } from './plugins.js';

function b64ToBytes(b64) {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

// {"Roboto":{"b64":"...","fallback":true}, ...} from the GET_FONTS AJAX callback -> pdfme options.font.
// With no fallback font in the table, the Roboto inside @pdfme/common is added, as the MLE side does.
function toPdfmeFonts(rows) {
  const font = {};
  let haveFallback = false;
  for (const [name, f] of Object.entries(rows || {})) {
    const fallback = !!f.fallback && !haveFallback;
    haveFallback = haveFallback || fallback;
    font[name] = { data: b64ToBytes(f.b64), fallback, subset: f.subset !== false };
  }
  if (!haveFallback) Object.assign(font, getDefaultFont());
  return font;
}

// A blank A4 template for "New template"
function blankTemplate() {
  return { basePdf: { width: 210, height: 297, padding: [10, 10, 10, 10] }, schemas: [[]] };
}

window.pdfmeApex = {
  Designer, plugins, BLANK_PDF, getInputFromTemplate, toPdfmeFonts, blankTemplate,
  version: '@pdfme/ui 6.2.8',
};
