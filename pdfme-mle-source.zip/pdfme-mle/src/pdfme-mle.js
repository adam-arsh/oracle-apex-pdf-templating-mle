// pdfme generate() for Oracle 23ai MLE.
//
// MLE module PDFME_BUNDLE exports these (PL/SQL call specifications: package PDFME_MLE, Step 6):
//   runJob(jobId)            reads PDFME_JOB + PDFME_TEMPLATE + PDFME_FONT and runs generate()
//   resultSize()             byte length of the last PDF (throws the last error, if there was one)
//   resultChunk(off, amt)    a slice of the last PDF as Uint8Array, which maps to RAW
//   clearResult()            frees the buffer
//   bundleInfo()             version string, for a smoke test
//
// The PDF comes back as RAW chunks, not as a BLOB, because Uint8Array <-> RAW is
// the simplest MLE type mapping. PDFME_PKG puts the chunks back together with
// DBMS_LOB.WRITEAPPEND.
import oracledb from 'mle-js-oracledb';
import { generate } from '@pdfme/generator';
import { BLANK_PDF, getDefaultFont } from '@pdfme/common';
import {
  text, multiVariableText, image, table, line, rectangle, ellipse, barcodes, checkbox,
} from '@pdfme/schemas';

const VERSION = 'pdfme-mle 1.0.0 / @pdfme/generator 6.2.8';

// Plugin keys are labels only; the schema "type" chooses the plugin.
const plugins = {
  Text: text,
  MultiVariableText: multiVariableText,
  Image: image,
  Table: table,
  Line: line,
  Rectangle: rectangle,
  Ellipse: ellipse,
  QRCode: barcodes.qrcode,
  Code128: barcodes.code128,
  Checkbox: checkbox,
};

// This state lives in the MLE context, which is per session and per module.
let lastPdf = null;
let lastError = null;
let fontCache = { token: null, font: null };

// ---------------------------------------------------------------- LOB helpers
function lobLength(lob) {
  if (typeof lob.length === 'function') return lob.length();
  if (typeof lob.getLength === 'function') return lob.getLength();
  throw new Error('Unsupported LOB object');
}

function toBytes(v) {
  if (v == null) return null;
  if (v instanceof Uint8Array) return v;
  if (ArrayBuffer.isView(v)) return new Uint8Array(v.buffer, v.byteOffset, v.byteLength);
  if (v instanceof ArrayBuffer) return new Uint8Array(v);
  if (typeof v.read === 'function') { // OracleBlob
    const len = lobLength(v);
    const out = new Uint8Array(len);
    const CH = 32000;
    for (let off = 0; off < len; off += CH) {
      out.set(v.read(Math.min(CH, len - off), off + 1), off);
    }
    return out;
  }
  throw new Error('Cannot convert value to bytes');
}

function toText(v) {
  if (v == null) return null;
  if (typeof v === 'string') return v;
  if (typeof v.read === 'function') { // OracleClob
    const len = lobLength(v);
    let s = '';
    const CH = 8000;
    for (let off = 0; off < len; off += CH) s += v.read(Math.min(CH, len - off), off + 1);
    return s;
  }
  return String(v);
}

function lobFetchInfo(clobCols, blobCols) {
  const fi = {};
  for (const c of clobCols) fi[c] = { type: oracledb.STRING };
  if (oracledb.UINT8ARRAY !== undefined) for (const c of blobCols) fi[c] = { type: oracledb.UINT8ARRAY };
  return fi;
}

// --------------------------------------------------------------------- fonts
function loadFonts(conn) {
  // Cache key: if any font row changes, the fonts are loaded again.
  const tok = conn.execute(
    `select count(*) || ':' || to_char(max(updated_on), 'yyyymmddhh24missff') as tok
       from pdfme_font where is_active = 'Y'`,
    [], { outFormat: oracledb.OUT_FORMAT_OBJECT }).rows[0].TOK;
  if (fontCache.token === tok && fontCache.font) return fontCache.font;

  const rs = conn.execute(
    `select font_name, font_data, is_fallback, is_subset
       from pdfme_font
      where is_active = 'Y'
      order by case is_fallback when 'Y' then 0 else 1 end, font_name`,
    [], { outFormat: oracledb.OUT_FORMAT_OBJECT, fetchInfo: lobFetchInfo([], ['FONT_DATA']) });

  const font = {};
  let haveFallback = false;
  for (const r of rs.rows) {
    const fallback = r.IS_FALLBACK === 'Y' && !haveFallback; // pdfme requires exactly one fallback
    if (fallback) haveFallback = true;
    font[r.FONT_NAME] = { data: toBytes(r.FONT_DATA), fallback, subset: r.IS_SUBSET !== 'N' };
  }
  // No fallback row: use the Roboto that ships inside @pdfme/common.
  // Then the bundle works before any font is loaded.
  if (!haveFallback) Object.assign(font, getDefaultFont());
  fontCache = { token: tok, font };
  return font;
}

// ------------------------------------------------------------------ template
function resolveBasePdf(tpl, basePdfBlob) {
  const bytes = toBytes(basePdfBlob);
  if (bytes && bytes.length) return bytes;                 // uploaded background PDF
  if (tpl.basePdf == null || tpl.basePdf === 'BLANK') return BLANK_PDF;
  return tpl.basePdf;                                      // {width,height,padding} or base64 data URI
}

// --------------------------------------------------------------------- API
export function bundleInfo() {
  return VERSION;
}

export function runJob(jobId) {
  lastPdf = null;
  lastError = null;
  try {
    const conn = oracledb.defaultConnection();
    const rs = conn.execute(
      `select t.template_json, t.base_pdf, j.inputs_json
         from pdfme_job j
         join pdfme_template t on t.template_id = j.template_id
        where j.job_id = :id`,
      [jobId],
      { outFormat: oracledb.OUT_FORMAT_OBJECT, fetchInfo: lobFetchInfo(['TEMPLATE_JSON', 'INPUTS_JSON'], ['BASE_PDF']) });
    if (!rs.rows.length) throw new Error(`PDFME_JOB ${jobId} not found`);
    const row = rs.rows[0];

    const tpl = JSON.parse(toText(row.TEMPLATE_JSON));
    let inputs = JSON.parse(toText(row.INPUTS_JSON) || '[{}]');
    if (!Array.isArray(inputs)) inputs = [inputs];
    tpl.basePdf = resolveBasePdf(tpl, row.BASE_PDF);

    const font = loadFonts(conn);

    // The chain settles within this call: there are no real timers (see polyfills.js).
    generate({ template: tpl, inputs, plugins, options: { font, title: tpl.title || 'pdfme' } })
      .then((pdf) => { lastPdf = pdf; })
      .catch((e) => { lastError = (e && e.stack) || String(e); });
  } catch (e) {
    lastError = (e && e.stack) || String(e);
  }
}

export function resultSize() {
  if (lastError) throw new Error('pdfme generate failed: ' + String(lastError).slice(0, 3500));
  if (!lastPdf) throw new Error('pdfme generate has not completed (no result in this session)');
  return lastPdf.length;
}

export function resultChunk(offset, amount) {
  // offset is 1-based, as in DBMS_LOB
  const start = offset - 1;
  return lastPdf.slice(start, Math.min(start + amount, lastPdf.length));
}

export function clearResult() {
  lastPdf = null;
  lastError = null;
}
