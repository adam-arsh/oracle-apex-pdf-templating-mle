// Schema types offered by the Designer (dist/pdfme-designer.min.js, APEX page 4).
// KEEP IN SYNC with `plugins` in src/pdfme-mle.js (the MLE generator): the two sets
// cover the same types, so anything drawn in the Designer renders in the database.
// To add a type (e.g. svg, date), add it in both places, rebuild both bundles, and
// reload the MLE module.
import {
  text, multiVariableText, image, table, line, rectangle, ellipse, barcodes, checkbox,
} from '@pdfme/schemas';

// Keys are the labels shown in the Designer sidebar; the schema "type" selects the plugin.
export const plugins = {
  Text: text,
  'Multi-variable text': multiVariableText,
  Image: image,
  Table: table,
  Line: line,
  Rectangle: rectangle,
  Ellipse: ellipse,
  'QR code': barcodes.qrcode,
  'Code 128': barcodes.code128,
  Checkbox: checkbox,
};
