// Polyfills for Oracle 23ai MLE (GraalJS): pure ECMAScript, no Node or browser globals.
// esbuild injects this file first (see build.mjs), so it runs before pdfme / pdf-lib / fontkit load.
import { Buffer } from 'buffer';

const g = globalThis;

if (typeof g.Buffer === 'undefined') g.Buffer = Buffer;

// MLE has no event loop. pdf-lib's save() yields with setTimeout(0), so the
// timer is mapped to a microtask, and the whole generate() promise chain
// settles inside the same database call.
if (typeof g.setTimeout === 'undefined') {
  g.setTimeout = (fn, _ms, ...args) => { Promise.resolve().then(() => fn(...args)); return 0; };
  g.clearTimeout = () => {};
}
if (typeof g.setInterval === 'undefined') {
  g.setInterval = () => 0;
  g.clearInterval = () => {};
}
if (typeof g.queueMicrotask === 'undefined') {
  g.queueMicrotask = (fn) => { Promise.resolve().then(fn); };
}

if (typeof g.atob === 'undefined') g.atob = (s) => Buffer.from(String(s), 'base64').toString('latin1');
if (typeof g.btoa === 'undefined') g.btoa = (s) => Buffer.from(String(s), 'latin1').toString('base64');

if (typeof g.TextEncoder === 'undefined') {
  g.TextEncoder = class TextEncoder {
    get encoding() { return 'utf-8'; }
    encode(s = '') { return new Uint8Array(Buffer.from(String(s), 'utf8')); }
  };
}

// fontkit asks for utf-8, utf-16be, 'ascii' and other single-byte code pages. Under the
// WHATWG Encoding standard, 'ascii', 'latin1' and 'iso-8859-1' all mean windows-1252.
// Oracle 23ai MLE has a native TextDecoder, but it only decodes UTF encodings: fontkit's
// module-level `new TextDecoder('ascii')` throws "RangeError: Encoding not supported: windows-1252".
// So the polyfill below is installed whenever the native decoder is missing OR rejects an encoding.
const CP1252_80_9F = [
  0x20ac, 0x81, 0x201a, 0x0192, 0x201e, 0x2026, 0x2020, 0x2021, 0x02c6, 0x2030, 0x0160, 0x2039, 0x0152, 0x8d, 0x017d, 0x8f,
  0x90, 0x2018, 0x2019, 0x201c, 0x201d, 0x2022, 0x2013, 0x2014, 0x02dc, 0x2122, 0x0161, 0x203a, 0x0153, 0x9d, 0x017e, 0x0178,
];
const normEnc = (e) => String(e || 'utf-8').trim().toLowerCase().replace(/_/g, '-');

class PolyTextDecoder {
  constructor(encoding = 'utf-8') { this._enc = normEnc(encoding); }
  get encoding() { return this._enc; }
  decode(input) {
    if (input == null) return '';
    const u8 = input instanceof Uint8Array ? input
      : ArrayBuffer.isView(input) ? new Uint8Array(input.buffer, input.byteOffset, input.byteLength)
      : new Uint8Array(input);
    const b = Buffer.from(u8.buffer, u8.byteOffset, u8.byteLength);
    switch (this._enc) {
      case 'utf-8': case 'utf8': case 'unicode-1-1-utf-8':
        return b.toString('utf8');
      case 'utf-16le': case 'utf-16': case 'ucs-2':
        return b.toString('utf16le');
      case 'utf-16be': {
        const sw = Buffer.from(b);
        for (let i = 0; i + 1 < sw.length; i += 2) { const t = sw[i]; sw[i] = sw[i + 1]; sw[i + 1] = t; }
        return sw.toString('utf16le');
      }
      case 'ascii': case 'us-ascii': case 'windows-1252': case 'cp1252': case 'latin1': case 'iso-8859-1': {
        let s = '';
        for (let i = 0; i < u8.length; i++) {
          const c = u8[i];
          s += String.fromCharCode(c >= 0x80 && c <= 0x9f ? CP1252_80_9F[c - 0x80] : c);
        }
        return s;
      }
      default: // other single-byte code pages: best-effort 1:1 byte mapping
        return b.toString('latin1');
    }
  }
}

const NativeTextDecoder = g.TextDecoder;
if (typeof NativeTextDecoder === 'undefined') {
  g.TextDecoder = PolyTextDecoder;
} else {
  // Use the native decoder where it works and the polyfill for any encoding it rejects
  g.TextDecoder = function TextDecoder(encoding = 'utf-8', options) {
    try {
      return new NativeTextDecoder(encoding, options);
    } catch (e) {
      return new PolyTextDecoder(encoding);
    }
  };
}

if (typeof g.structuredClone === 'undefined') {
  g.structuredClone = (v) => (v === undefined ? v : JSON.parse(JSON.stringify(v)));
}

// @pdfme/schemas creates `new EventTarget()` when it loads (radioGroup UI). The
// UI never runs in the database, but the constructors must exist.
if (typeof g.Event === 'undefined') {
  g.Event = class Event { constructor(type, init = {}) { this.type = type; Object.assign(this, init); } };
}
if (typeof g.CustomEvent === 'undefined') {
  g.CustomEvent = class CustomEvent extends g.Event {
    constructor(type, init = {}) { super(type, init); this.detail = init.detail; }
  };
}
if (typeof g.EventTarget === 'undefined') {
  g.EventTarget = class EventTarget {
    constructor() { this._l = new Map(); }
    addEventListener(t, fn) { if (!this._l.has(t)) this._l.set(t, new Set()); this._l.get(t).add(fn); }
    removeEventListener(t, fn) { this._l.get(t)?.delete(fn); }
    dispatchEvent(e) { this._l.get(e.type)?.forEach((fn) => fn.call(this, e)); return true; }
  };
}
