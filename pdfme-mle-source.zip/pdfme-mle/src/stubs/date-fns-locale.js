// Stub for 'date-fns/locale': only en-US. The date/time plugins are not registered in
// pdfme-mle.js, and the full locale set adds ~1 MB plus non-ASCII regex literals.
export { enUS } from 'date-fns/locale/en-US';
