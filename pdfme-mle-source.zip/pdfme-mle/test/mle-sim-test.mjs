// Runs dist/pdfme_mle_bundle.js the way MLE does, before you load it into the database:
//  - a fresh vm context, so there is no Buffer, setTimeout, TextEncoder/TextDecoder, atob or fetch
//  - microtaskMode 'afterEvaluate': promises settle only inside each "call", with no event loop
//  - a TextDecoder that decodes UTF only, like the native one in MLE
//  - a fake 'mle-js-oracledb' that serves the PDFME_JOB / PDFME_TEMPLATE / PDFME_FONT rows and
//    returns LOBs as OracleBlob-like objects, which exercises the chunked read path
//
//   npm test                    runs the built-in template, twice (cold, then warm)
//   npm test -- skill_cert      runs templates/skill_cert.template.json with skill_cert.inputs.json
import vm from 'node:vm';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';

const root = new URL('../', import.meta.url);
const bundleSrc = readFileSync(new URL('dist/pdfme_mle_bundle.js', root), 'utf8');
mkdirSync(new URL('out/', root), { recursive: true });

// A small template that touches the main field types: a box, a line, fixed text, dynamic text, a QR code.
const BUILT_IN = {
  template: JSON.stringify({
    basePdf: { width: 210, height: 297, padding: [0, 0, 0, 0] },
    schemas: [[
      { name: 'frame', type: 'rectangle', readOnly: true, position: { x: 10, y: 10 }, width: 190, height: 277, borderWidth: 0.6, borderColor: '#1f4e79', color: '', radius: 0 },
      { name: 'title', type: 'text', readOnly: true, content: 'MLE smoke test', position: { x: 20, y: 20 }, width: 170, height: 10, fontSize: 20, alignment: 'left', fontColor: '#1f4e79' },
      { name: 'rule', type: 'line', readOnly: true, position: { x: 20, y: 34 }, width: 170, height: 0.5, color: '#9dc3e6' },
      { name: 'message', type: 'text', position: { x: 20, y: 42 }, width: 170, height: 8, fontSize: 12, content: 'message' },
      { name: 'verify', type: 'qrcode', position: { x: 20, y: 60 }, width: 30, height: 30, content: 'https://example.com' },
    ]],
  }),
  inputs: JSON.stringify([{ message: 'Hello from a JavaScript module', verify: 'https://example.com/verify/1' }]),
};

const name = process.argv[2];
const job = name
  ? {
      template: readFileSync(new URL(`templates/${name}.template.json`, root), 'utf8'),
      inputs: readFileSync(new URL(`templates/${name}.inputs.json`, root), 'utf8'),
    }
  : BUILT_IN;
const label = name || 'built-in';

const ctx = vm.createContext({}, { microtaskMode: 'afterEvaluate' });
const missing = ['Buffer', 'setTimeout', 'TextDecoder', 'TextEncoder', 'atob', 'fetch', 'process']
  .filter((n) => vm.runInContext(`typeof ${n}`, ctx) !== 'undefined');
if (missing.length) throw new Error('vm context unexpectedly has ' + missing);

// Like Oracle 23ai MLE: a native TextDecoder that decodes UTF only, so that
// new TextDecoder('ascii') throws "RangeError: Encoding not supported: windows-1252"
vm.runInContext(`
  globalThis.TextDecoder = class TextDecoder {
    constructor(enc = 'utf-8') {
      const e = String(enc).toLowerCase();
      const map = { 'utf-8': 'utf-8', utf8: 'utf-8', 'utf-16le': 'utf-16le', 'utf-16be': 'utf-16be', 'utf-16': 'utf-16le' };
      if (!map[e]) throw new RangeError('Encoding not supported: ' + (['ascii', 'us-ascii', 'latin1', 'iso-8859-1'].includes(e) ? 'windows-1252' : e));
      this.encoding = map[e];
    }
    decode(u8) {
      if (!u8) return '';
      u8 = u8 instanceof Uint8Array ? u8 : new Uint8Array(u8.buffer || u8);
      let s = '';
      if (this.encoding === 'utf-8') { for (const b of u8) s += '%' + b.toString(16).padStart(2, '0'); try { return decodeURIComponent(s); } catch { return ''; } }
      const be = this.encoding === 'utf-16be';
      for (let i = 0; i + 1 < u8.length; i += 2) s += String.fromCharCode(be ? (u8[i] << 8) | u8[i + 1] : (u8[i + 1] << 8) | u8[i]);
      return s;
    }
  };`, ctx);

// The current job is exposed to the fake driver through this host object.
const host = { job };
ctx.__host = host;

const oracledbSrc = `
  const h = globalThis.__host;
  const oracledb = {
    OUT_FORMAT_OBJECT: 4002, STRING: 2001,
    defaultConnection() {
      return {
        execute(sql) {
          const s = sql.toLowerCase();
          if (s.includes('from pdfme_job')) {
            return { rows: [{ TEMPLATE_JSON: h.job.template, BASE_PDF: null, INPUTS_JSON: h.job.inputs }] };
          }
          if (s.includes('count(*)')) return { rows: [{ TOK: '0:none' }] };
          if (s.includes('from pdfme_font')) return { rows: [] };   // no font rows: the bundle falls back to its own Roboto
          throw new Error('unexpected SQL: ' + sql);
        },
      };
    },
  };
  export default oracledb;`;

const modOracledb = new vm.SourceTextModule(oracledbSrc, { context: ctx, identifier: 'mle-js-oracledb' });
const modBundle = new vm.SourceTextModule(bundleSrc, { context: ctx, identifier: 'pdfme_bundle' });
const modMain = new vm.SourceTextModule(`import * as m from 'pdfme_bundle'; globalThis.__m = m;`, { context: ctx });
const link = async (spec) => {
  if (spec === 'mle-js-oracledb') return modOracledb;
  if (spec === 'pdfme_bundle') return modBundle;
  throw new Error('unresolved import ' + spec);
};
await modMain.link(link);
await modMain.evaluate();

const call = (code) => new vm.Script(code).runInContext(ctx); // one call = one MLE "top-level call"

console.log('bundleInfo:', call('__m.bundleInfo()'));
for (const run of ['cold', 'warm']) {
  const t0 = Date.now();
  call('__m.runJob(1)');                                         // like: pdfme_mle.run_job(1)
  const size = call('__m.resultSize()');                         // pdfme_mle.result_size
  const parts = [];
  for (let off = 1; off <= size; off += 32000) parts.push(call(`__m.resultChunk(${off}, 32000)`));
  const pdf = Buffer.concat(parts.map((p) => Buffer.from(p)));
  call('__m.clearResult()');
  console.log(`${run}: ${size} bytes in ${Date.now() - t0} ms, header=${pdf.subarray(0, 5).toString()}`);
  if (run === 'warm') writeFileSync(new URL(`out/${label}.pdf`, root), pdf);
}
console.log(`written: out/${label}.pdf`);
